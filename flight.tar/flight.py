import mysql.connector
from mysql.connector import pooling, Error
from typing import Optional, Tuple, Any, List
from datetime import datetime

# ----------------------------------------------------------------------
# 1. CONFIGURATION & CONNECTION POOLING
# ----------------------------------------------------------------------

DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '1905',
    'database': 'cs'}

# Create a pool instead of opening new connections each time
connection_pool = pooling.MySQLConnectionPool(pool_name="flight_pool", pool_size=5, **DB_CONFIG)


# ----------------------------------------------------------------------
# 2. VALIDATION HELPERS
# ----------------------------------------------------------------------

def input_nonempty(prompt: str) -> str:
    while True:
        value = input(prompt).strip()
        if value:
            return value
        print("❌ Value cannot be empty.")


def input_alpha(prompt: str) -> str:
    while True:
        value = input(prompt).strip()
        if value.isalpha():
            return value
        print("❌ Please enter only alphabets.")


def input_positive_int(prompt: str) -> int:
    while True:
        try:
            val = int(input(prompt).strip())
            if val > 0:
                return val
            print("❌ Enter a positive number.")
        except ValueError:
            print("❌ Invalid input. Please enter an integer.")


def input_gender(prompt: str) -> str:
    while True:
        g = input(prompt).strip().upper()
        if g in ('M', 'F'):
            return g
        print("❌ Enter 'M' for Male or 'F' for Female.")


def input_date(prompt: str) -> str:
    while True:
        d = input(prompt).strip()
        try:
            datetime.strptime(d, "%Y-%m-%d")
            return d
        except ValueError:
            print("❌ Invalid format. Use YYYY-MM-DD.")


# ----------------------------------------------------------------------
# 3. DATABASE HELPERS
# ----------------------------------------------------------------------

def get_connection():
    """Fetch a connection from the pool."""
    return connection_pool.get_connection()


def execute_query(query: str, params: Tuple = (), fetch: bool = False):
    """General-purpose DB executor."""
    with get_connection() as con, con.cursor() as cur:
        cur.execute(query, params)
        if fetch:
            return cur.fetchall()
        con.commit()


# ----------------------------------------------------------------------
# 4. FLIGHT OPERATIONS
# ----------------------------------------------------------------------

def view_all_flights():
    flights = execute_query("SELECT * FROM Flight", fetch=True)
    if not flights:
        print("No flights available.")
        return
    print("\n--- ALL FLIGHTS ---")
    for f in flights:
        print(f)


def view_all_passengers():
    passengers = execute_query("SELECT * FROM Passenger", fetch=True)
    if not passengers:
        print("No passengers found.")
        return
    print("\n--- ALL PASSENGERS ---")
    for p in passengers:
        print(p)


def view_passengers_by_flight():
    f_id = input_nonempty("Enter Flight ID: ").upper()
    passengers = execute_query("SELECT * FROM Passenger WHERE FlightID=%s", (f_id,), fetch=True)
    if passengers:
        print(f"\nPassengers for Flight {f_id}:")
        for p in passengers:
            print(p)
    else:
        print(f"No passengers for Flight {f_id}.")


def add_new_flight():
    print("\n--- ADD NEW FLIGHT ---")
    flight_id = input_nonempty("Flight ID: ").upper()
    airline = input_nonempty("Airline Name: ")
    source = input_nonempty("Source: ")
    destination = input_nonempty("Destination: ")
    dep_time = input_nonempty("Departure Time (HH:MM:SS): ")
    arr_time = input_nonempty("Arrival Time (HH:MM:SS): ")
    capacity = input_positive_int("Capacity: ")

    query = """
        INSERT INTO Flight (FlightID, Airline, Source, Destination, DepartureTime, Arrival, Capacity, AvailableSeats)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
    """
    try:
        execute_query(query, (flight_id, airline, source, destination, dep_time, arr_time, capacity, capacity))
        print("✅ Flight added successfully.")
    except Error as e:
        print(f"❌ Database error: {e}")


# ----------------------------------------------------------------------
# 5. BOOKING OPERATIONS
# ----------------------------------------------------------------------

def booking():
    f_id = input_nonempty("Enter Flight ID: ").upper()
    tickets = input_positive_int("Number of tickets: ")

    seats = execute_query("SELECT AvailableSeats FROM Flight WHERE FlightID=%s", (f_id,), fetch=True)
    if not seats:
        print("❌ Flight not found.")
        return
    available = seats[0][0]
    if tickets > available:
        print(f"❌ Only {available} seats available.")
        return

    name = input_alpha("Passenger Name: ")
    age = input_positive_int("Age: ")
    gender = input_gender("Gender (M/F): ")
    dob = input_date("Date of Birth (YYYY-MM-DD): ")

    try:
        add_query = """
            INSERT INTO Passenger (PassengerName, Age, Gender, DOB, NumTickets, FlightID)
            VALUES (%s, %s, %s, %s, %s, %s)
        """
        execute_query(add_query, (name, age, gender, dob, tickets, f_id))

        update_query = "UPDATE Flight SET AvailableSeats = AvailableSeats - %s WHERE FlightID=%s"
        execute_query(update_query, (tickets, f_id))

        print("✅ Booking successful.")
    except Error as e:
        print(f"❌ Booking failed: {e}")


# ----------------------------------------------------------------------
# 6. CANCELLATION
# ----------------------------------------------------------------------

def cancel_booking():
    pid = input_positive_int("Passenger ID: ")
    name = input_nonempty("Passenger Name: ")
    age = input_positive_int("Age: ")
    gender = input_gender("Gender (M/F): ")
    dob = input_date("Date of Birth (YYYY-MM-DD): ")

    record = execute_query(
        "SELECT FlightID, NumTickets, PassengerName, Age, Gender, DOB FROM Passenger WHERE PassengerID=%s",
        (pid,),
        fetch=True)
    if not record:
        print("❌ Passenger not found.")
        return

    flight_id, num_tickets, db_name, db_age, db_gender, db_dob = record[0]

    if (db_name.strip() != name.strip() or db_age != age or db_gender.upper() != gender.upper()
            or str(db_dob) != dob):
        print("❌ Verification failed. Details do not match.")
        return

    try:
        execute_query("DELETE FROM Passenger WHERE PassengerID=%s", (pid,))
        execute_query("UPDATE Flight SET AvailableSeats = AvailableSeats + %s WHERE FlightID=%s",
                      (num_tickets, flight_id))
        print("✅ Cancellation successful.")
    except Error as e:
        print(f"❌ Cancellation failed: {e}")


# ----------------------------------------------------------------------
# 7. MAIN MENU
# ----------------------------------------------------------------------

def main_menu():
    while True:
        print("\n" + "=" * 40)
        print("✈️ RKD AIRLINES MENU ✈️")
        print("=" * 40)
        print("1. View Flights")
        print("2. View Passengers")
        print("3. View Passengers by Flight")
        print("4. Add Flight")
        print("5. Book Ticket")
        print("6. Cancel Ticket")
        print("7. Exit")

        ch = input("Enter choice: ").strip()
        if ch == '1':
            view_all_flights()
        elif ch == '2':
            view_all_passengers()
        elif ch == '3':
            view_passengers_by_flight()
        elif ch == '4':
            add_new_flight()
        elif ch == '5':
            booking()
        elif ch == '6':
            cancel_booking()
        elif ch == '7':
            print("Goodbye 👋")
            break
        else:
            print("❌ Invalid choice.")


if __name__ == "__main__":
    try:
        conn = get_connection()
        conn.close()
        print("✅ Database connection successful.")
        main_menu()
    except Error as e:
        print(f"❌ Could not connect to database: {e}")
